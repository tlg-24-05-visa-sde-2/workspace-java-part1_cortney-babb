enum DisplayType {
    LED, OLED, PLASMA, LCD, CRT
}